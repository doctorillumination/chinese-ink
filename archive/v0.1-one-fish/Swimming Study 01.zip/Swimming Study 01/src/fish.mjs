import * as THREE from '../vendor/three.module.js';
import { BODY_LENGTH, JOINT_COUNT, clamp } from './simulation.mjs';

const mix = (a, b, t) => a + (b - a) * t;
const PROFILE = [
  [0, 0.058, 0.075, 0.058], [0.045, 0.16, 0.14, 0.115],
  [0.13, 0.278, 0.255, 0.205], [0.26, 0.375, 0.345, 0.26],
  [0.38, 0.35, 0.34, 0.245], [0.53, 0.275, 0.285, 0.185],
  [0.68, 0.175, 0.205, 0.13], [0.82, 0.095, 0.12, 0.076],
  [0.94, 0.048, 0.066, 0.048], [1, 0.028, 0.045, 0.035],
];

export function profile(s) {
  s = clamp(s, 0, 1);
  let j = 0;
  while (j < PROFILE.length - 2 && PROFILE[j + 1][0] < s) j++;
  const a = PROFILE[j];
  const b = PROFILE[j + 1];
  const u = (s - a[0]) / (b[0] - a[0]);
  const out = [];
  // Monotone cubic interpolation keeps the profile smooth without overshoot.
  for (let k = 1; k <= 3; k++) {
    const m = (b[k] - a[k]) / (b[0] - a[0]);
    const slope = (index) => {
      if (index === 0) return (PROFILE[1][k] - PROFILE[0][k]) / (PROFILE[1][0] - PROFILE[0][0]);
      if (index === PROFILE.length - 1) return m;
      const l = (PROFILE[index][k] - PROFILE[index - 1][k]) / (PROFILE[index][0] - PROFILE[index - 1][0]);
      const r = (PROFILE[index + 1][k] - PROFILE[index][k]) / (PROFILE[index + 1][0] - PROFILE[index][0]);
      return l * r <= 0 ? 0 : 2 * l * r / (l + r);
    };
    const d = b[0] - a[0];
    out.push((2*u*u*u-3*u*u+1)*a[k]+(u*u*u-2*u*u+u)*d*slope(j)+(-2*u*u*u+3*u*u)*b[k]+(u*u*u-u*u)*d*slope(j+1));
  }
  return out;
}

function dynamicGeometry(count, indices) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 3), 3).setUsage(THREE.DynamicDrawUsage));
  if (indices) g.setIndex(indices);
  return g;
}

export class ProceduralFish {
  constructor(scene, simulation) {
    this.sim = simulation;
    this.group = new THREE.Group();
    scene.add(this.group);
    this.rings = 81;
    this.radials = 32;
    const indices = [];
    for (let i = 0; i < this.rings - 1; i++) {
      for (let j = 0; j < this.radials; j++) {
        const a = i * this.radials + j;
        const b = i * this.radials + (j + 1) % this.radials;
        const c = a + this.radials;
        const d = b + this.radials;
        indices.push(a, b, c, b, d, c);
      }
    }
    // Caps close the snout and the tail peduncle.
    const count = this.rings * this.radials;
    for (let j = 0; j < this.radials; j++) {
      indices.push(count, (j + 1) % this.radials, j);
      const base = (this.rings - 1) * this.radials;
      indices.push(count + 1, base + j, base + (j + 1) % this.radials);
    }
    this.geometry = dynamicGeometry(count + 2, indices);
    const colors = new Float32Array((count + 2) * 3);
    const dark = new THREE.Color('#647672');
    const light = new THREE.Color('#c3c9be');
    for (let i = 0; i < this.rings; i++) {
      for (let j = 0; j < this.radials; j++) {
        const theta = j / this.radials * Math.PI * 2;
        const belly = Math.pow((1 - Math.sin(theta)) / 2, 1.8);
        const color = dark.clone().lerp(light, belly * 0.86);
        color.toArray(colors, (i * this.radials + j) * 3);
      }
    }
    dark.toArray(colors, count * 3);
    dark.toArray(colors, (count + 1) * 3);
    this.geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    this.material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.48, metalness: 0.035 });
    this.body = new THREE.Mesh(this.geometry, this.material);
    this.body.castShadow = true;
    this.body.frustumCulled = false;
    this.group.add(this.body);

    this.finMaterial = new THREE.MeshStandardMaterial({ color: '#8c9e97', roughness: 0.58, metalness: 0, side: THREE.DoubleSide, transparent: true, opacity: 0.74, depthWrite: false });
    this.finRaysMaterial = new THREE.LineBasicMaterial({ color: '#536d64', transparent: true, opacity: 0.34 });
    this.fins = [];
    for (const side of [-1, 1]) {
      this.makeFin({ type: 'paired', side, s: 0.26, width: 0.335, height: -0.10, length: 0.64 });
      this.makeFin({ type: 'paired', side, s: 0.61, width: 0.205, height: -0.11, length: 0.33 });
    }
    this.makeFin({ type: 'dorsal' });
    this.makeFin({ type: 'anal' });
    this.makeFin({ type: 'tail' });

    this.details = new THREE.Group();
    this.group.add(this.details);
    this.eyes = [];
    const eyeGeometry = new THREE.SphereGeometry(1, 20, 14);
    for (const side of [-1, 1]) {
      const eye = new THREE.Mesh(eyeGeometry, new THREE.MeshStandardMaterial({ color: '#343f3d', roughness: 0.24 }));
      const pupil = new THREE.Mesh(eyeGeometry, new THREE.MeshStandardMaterial({ color: '#101b19', roughness: 0.18 }));
      eye.scale.set(0.065, 0.052, 0.032);
      pupil.scale.set(0.036, 0.035, 0.014);
      this.details.add(eye, pupil);
      this.eyes.push({ eye, pupil, side });
    }
    this.gills = [];
    for (const side of [-1, 1]) {
      const g = dynamicGeometry(30);
      const line = new THREE.Line(g, new THREE.LineBasicMaterial({ color: '#4d605a', transparent: true, opacity: 0.62 }));
      line.frustumCulled = false;
      this.details.add(line);
      this.gills.push({ line, side });
    }
    this.mouth = new THREE.LineLoop(dynamicGeometry(40), new THREE.LineBasicMaterial({ color: '#495c54', transparent: true, opacity: 0.8 }));
    this.mouth.frustumCulled = false;
    this.details.add(this.mouth);

    this.spineGroup = new THREE.Group();
    scene.add(this.spineGroup);
    this.joints = [];
    this.links = [];
    const ballGeometry = new THREE.SphereGeometry(0.027, 10, 8);
    const linkGeometry = new THREE.CylinderGeometry(0.009, 0.009, 1, 7);
    for (let i = 0; i < JOINT_COUNT; i++) {
      const color = new THREE.Color('#f5d9a5').lerp(new THREE.Color('#c26943'), i / (JOINT_COUNT - 1));
      const material = new THREE.MeshBasicMaterial({ color, depthTest: false, depthWrite: false, transparent: true, opacity: 0.95 });
      const joint = new THREE.Mesh(ballGeometry, material);
      joint.renderOrder = 20;
      joint.frustumCulled = false;
      this.spineGroup.add(joint);
      this.joints.push(joint);
      if (i) {
        const link = new THREE.Mesh(linkGeometry, material);
        link.renderOrder = 19;
        link.frustumCulled = false;
        this.spineGroup.add(link);
        this.links.push(link);
      }
    }
    this.upAxis = new THREE.Vector3(0, 1, 0);
    this.v1 = new THREE.Vector3();
    this.v2 = new THREE.Vector3();
    this.update();
  }

  frame(s) {
    const spine = this.sim.spine;
    const n = spine.length;
    const u = clamp(s, 0, 1) * (n - 1);
    const i = Math.min(n - 2, Math.floor(u));
    const f = u - i;
    const a = spine[i];
    const b = spine[i + 1];
    const forward = new THREE.Vector3(a.x - b.x, a.y - b.y, a.z - b.z).normalize();
    const center = new THREE.Vector3(mix(a.x, b.x, f), mix(a.y, b.y, f), mix(a.z, b.z, f));
    if (s > 1) center.addScaledVector(forward, -(s - 1) * BODY_LENGTH);
    const right = new THREE.Vector3(-forward.z, 0, forward.x).normalize();
    const up = new THREE.Vector3().crossVectors(right, forward).normalize();
    return { center, forward, right, up };
  }

  point(s, right, height) {
    const f = this.frame(s);
    return f.center.addScaledVector(f.right, right).addScaledVector(f.up, height);
  }

  makeFin(spec) {
    const nu = spec.type === 'tail' ? 20 : 16;
    const nv = 9;
    const indices = [];
    const rayIndices = [];
    for (let i = 0; i < nu; i++) {
      for (let j = 0; j < nv; j++) {
        const a = i * (nv + 1) + j;
        const b = a + nv + 1;
        indices.push(a, b, a + 1, a + 1, b, b + 1);
      }
    }
    for (let i = 0; i <= nu; i += 2) {
      for (let j = 0; j < nv; j++) rayIndices.push(i * (nv + 1) + j, i * (nv + 1) + j + 1);
    }
    const geometry = dynamicGeometry((nu + 1) * (nv + 1), indices);
    const mesh = new THREE.Mesh(geometry, this.finMaterial);
    mesh.frustumCulled = false;
    this.group.add(mesh);
    const rays = new THREE.LineSegments(dynamicGeometry(rayIndices.length), this.finRaysMaterial);
    rays.frustumCulled = false;
    this.group.add(rays);
    this.fins.push({ spec, nu, nv, geometry, mesh, rays, rayIndices });
  }

  finPoint(spec, u, v) {
    const sim = this.sim;
    const phase = sim.phase;
    if (spec.type === 'paired') {
      const theta = mix(-0.42, 1.16, u);
      const slow = clamp(1 - sim.speed / (BODY_LENGTH * 0.55), 0, 1);
      const inside = Math.max(0, sim.omega * spec.side);
      const spread = clamp(0.49 + slow * 0.36 + sim.effort * 0.15 + inside * 0.37, 0.35, 1.15);
      const radius = spec.length * (0.83 + Math.sin(u * Math.PI) * 0.17) * v;
      const s = spec.s + (Math.sin(theta) * radius + (1 - sim.effort) * radius * 0.38) / BODY_LENGTH;
      const paddle = Math.sin(phase * 0.63 - u * 1.2 - v * 0.7 + spec.side * 0.3) * (0.035 + slow * 0.075) * v;
      return this.point(s, spec.side * (spec.width + Math.cos(theta) * radius * spread), spec.height - radius * 0.16 + paddle);
    }
    if (spec.type === 'dorsal' || spec.type === 'anal') {
      const dorsal = spec.type === 'dorsal';
      const s = mix(dorsal ? 0.27 : 0.65, dorsal ? 0.77 : 0.85, u);
      const body = profile(s);
      const outline = (dorsal ? 0.27 : 0.13) * Math.pow(Math.sin(u * Math.PI), 0.85);
      const y = (dorsal ? body[1] * 0.93 + outline * v : -body[2] * 0.92 - outline * v);
      const lag = Math.sin(phase - s * 5.8 - v * 0.8) * sim.effort * 0.045 * v;
      return this.point(s + v * 0.028, lag, y);
    }
    const lobe = Math.abs(u * 2 - 1);
    const s = 0.985 + (0.165 + 0.085 * Math.pow(lobe, 1.7)) * v;
    const y = (u - 0.5) * mix(0.09, 1.02, v);
    const lag = Math.sin(phase - 5.8 - v * 1.1) * (0.022 + sim.effort * 0.17) * v;
    // A slight cup gives the vertical caudal fin volume when viewed from above.
    return this.point(s, lag + Math.sin(u * Math.PI) * v * 0.045, y);
  }

  update() {
    const sim = this.sim;
    sim.updateSpine();
    const positions = this.geometry.attributes.position;
    for (let i = 0; i < this.rings; i++) {
      const s = i / (this.rings - 1);
      const [width, back, belly] = profile(s);
      const frame = this.frame(s);
      for (let j = 0; j < this.radials; j++) {
        const theta = j / this.radials * Math.PI * 2;
        const sine = Math.sin(theta);
        const y = sine * (sine >= 0 ? back : belly);
        const point = frame.center.clone().addScaledVector(frame.right, Math.cos(theta) * width).addScaledVector(frame.up, y);
        positions.setXYZ(i * this.radials + j, point.x, point.y, point.z);
      }
    }
    const cap = this.rings * this.radials;
    const head = sim.spine[0];
    const tail = sim.spine[sim.spine.length - 1];
    positions.setXYZ(cap, head.x, head.y, head.z);
    positions.setXYZ(cap + 1, tail.x, tail.y, tail.z);
    positions.needsUpdate = true;
    this.geometry.computeVertexNormals();
    for (const fin of this.fins) {
      const p = fin.geometry.attributes.position;
      for (let i = 0; i <= fin.nu; i++) {
        for (let j = 0; j <= fin.nv; j++) {
          const point = this.finPoint(fin.spec, i / fin.nu, j / fin.nv);
          p.setXYZ(i * (fin.nv + 1) + j, point.x, point.y, point.z);
        }
      }
      p.needsUpdate = true;
      fin.geometry.computeVertexNormals();
      const rays = fin.rays.geometry.attributes.position;
      for (let k = 0; k < fin.rayIndices.length; k++) {
        const i = fin.rayIndices[k];
        rays.setXYZ(k, p.getX(i), p.getY(i), p.getZ(i));
      }
      rays.needsUpdate = true;
    }
    const headFrame = this.frame(0.085);
    const basis = new THREE.Matrix4().makeBasis(headFrame.forward, headFrame.up, headFrame.right);
    const rotation = new THREE.Quaternion().setFromRotationMatrix(basis);
    for (const { eye, pupil, side } of this.eyes) {
      eye.position.copy(this.point(0.08, side * 0.218, 0.097));
      pupil.position.copy(this.point(0.077, side * 0.244, 0.101));
      eye.quaternion.copy(rotation);
      pupil.quaternion.copy(rotation);
    }
    for (const { line, side } of this.gills) {
      const p = line.geometry.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const a = mix(-0.72, 1.2, i / (p.count - 1));
        const s = 0.183 + 0.033 * Math.cos(a);
        const [w, h, b] = profile(s);
        const point = this.point(s, side * Math.cos(a) * (w + 0.004), Math.sin(a) * (a >= 0 ? h : b));
        p.setXYZ(i, point.x, point.y, point.z);
      }
      p.needsUpdate = true;
    }
    const mouth = this.mouth.geometry.attributes.position;
    for (let i = 0; i < mouth.count; i++) {
      const a = i / mouth.count * Math.PI * 2;
      const point = this.point(-0.001, Math.cos(a) * 0.043, Math.sin(a) * 0.025 - 0.021);
      point.addScaledVector(this.frame(0).forward, 0.004);
      mouth.setXYZ(i, point.x, point.y, point.z);
    }
    mouth.needsUpdate = true;
    for (let i = 0; i < sim.spine.length; i++) {
      const point = sim.spine[i];
      this.joints[i].position.set(point.x, point.y, point.z);
      if (i) {
        const a = sim.spine[i - 1];
        this.v1.set(point.x - a.x, point.y - a.y, point.z - a.z);
        const link = this.links[i - 1];
        link.position.set((point.x + a.x) / 2, (point.y + a.y) / 2, (point.z + a.z) / 2);
        link.scale.y = this.v1.length();
        link.quaternion.setFromUnitVectors(this.upAxis, this.v1.normalize());
      }
    }
  }

  setInspection({ spine, translucent, wireframe }) {
    this.spineGroup.visible = spine;
    this.material.transparent = translucent;
    this.material.opacity = translucent ? 0.38 : 1;
    this.material.depthWrite = !translucent;
    this.material.wireframe = wireframe;
    this.material.needsUpdate = true;
  }
}
