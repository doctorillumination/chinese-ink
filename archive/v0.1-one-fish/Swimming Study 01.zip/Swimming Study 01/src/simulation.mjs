// Original motion study. Distances use body lengths only at the UI boundary.
export const BODY_LENGTH = 3.05;
export const JOINT_COUNT = 29;
export const FIXED_STEP = 1 / 120;
export const DEFAULTS = Object.freeze({
  speed: 0.46,
  amplitude: 1,
  tempo: 1,
  stiffness: 0.72,
  rhythm: 0.82,
  drag: 0.45,
  turn: 0,
  wander: 0.7,
});

export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const mix = (a, b, t) => a + (b - a) * t;
const approach = (a, b, rate, dt) => mix(a, b, 1 - Math.exp(-rate * dt));
export const angleDifference = (a, b) => Math.atan2(Math.sin(a - b), Math.cos(a - b));
const smoothstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

function hash(n, seed) {
  let x = (n + Math.imul(seed, 374761393)) | 0;
  x = Math.imul(x ^ (x >>> 13), 1274126177);
  return ((x ^ (x >>> 16)) >>> 0) / 4294967295;
}

function noise(t, seed) {
  const n = Math.floor(t);
  const u = t - n;
  return mix(hash(n, seed), hash(n + 1, seed), u * u * (3 - 2 * u)) * 2 - 1;
}

export class FishSimulation {
  constructor(params = {}) {
    this.params = { ...DEFAULTS, ...params };
    this.seed = 1729;
    this.mode = 'wander';
    this.reset();
  }

  reset() {
    this.time = 0;
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.yaw = 0;
    this.omega = 0;
    this.speed = this.params.speed * BODY_LENGTH * 0.88;
    this.distance = 0;
    this.phase = 0;
    this.effort = 0.45;
    this.frequency = 1.1;
    this.beating = true;
    this.stateTime = 0;
    this.glideUntil = 0;
    this.burstUntil = 0;
    this.target = null;
    this.history = [];
    for (let d = -BODY_LENGTH * 3; d <= 0.001; d += 0.04) {
      this.history.push({ x: d, y: 0, z: 0, yaw: 0, d });
    }
    this.history.push({ x: 0, y: 0, z: 0, yaw: 0, d: 0 });
    this.spine = Array.from({ length: JOINT_COUNT }, () => ({ x: 0, y: 0, z: 0 }));
    this.updateSpine();
  }

  setTarget(x, z, persistent = false) {
    if (Number.isFinite(x) && Number.isFinite(z)) {
      this.target = { x, z, expires: persistent ? Infinity : this.time + 18 };
    }
  }

  burst() {
    this.burstUntil = this.time + 2.2;
    this.glideUntil = 0;
    this.beating = true;
  }

  glide() {
    this.glideUntil = this.time + 3.5;
    this.burstUntil = 0;
    this.beating = false;
  }

  step(dt = FIXED_STEP) {
    const p = this.params;
    this.time += dt;
    this.stateTime += dt;
    if (this.target && this.target.expires < this.time) this.target = null;

    let turnWish = 0;
    let arrival = 1;
    if (this.target && this.mode !== 'straight') {
      const dx = this.target.x - this.x;
      const dz = this.target.z - this.z;
      const d = Math.hypot(dx, dz);
      turnWish = angleDifference(Math.atan2(dz, dx), this.yaw) * 1.4;
      arrival = mix(0.18, 1, smoothstep(0.35, 2.5, d));
      if (d < 0.3 && this.target.expires !== Infinity) this.target = null;
    } else if (this.mode === 'wander') {
      turnWish = noise(this.time * 0.17 + 3, this.seed) * p.wander * 0.75;
      turnWish += noise(this.time * 0.049 + 11, this.seed + 7) * p.wander * 0.26;
      const lookX = this.x + Math.cos(this.yaw) * this.speed * 2.2;
      const lookZ = this.z + Math.sin(this.yaw) * this.speed * 2.2;
      const edge = smoothstep(7, 12, Math.hypot(lookX, lookZ));
      const home = angleDifference(Math.atan2(-this.z, -this.x), this.yaw);
      turnWish = mix(turnWish, home * 0.8, edge);
    }
    turnWish += p.turn * 0.8;
    // Fin-assisted slow turns remain possible; rapid pivots do not.
    const maxTurn = clamp(this.speed / (BODY_LENGTH * 0.78), 0.12, 0.92);
    const desiredOmega = clamp(turnWish, -maxTurn, maxTurn);
    const nextOmega = approach(this.omega, desiredOmega, 2.9, dt);
    this.omega += clamp(nextOmega - this.omega, -1.15 * dt, 1.15 * dt);
    this.yaw += this.omega * dt;

    const bursting = this.time < this.burstUntil;
    const forcedGlide = this.time < this.glideUntil;
    const targetSpeed = p.speed * BODY_LENGTH * arrival * (bursting ? 1.65 : 1);
    const dragAt = (v) => (0.105 + p.drag * 0.2) * v * (1 + v * 0.27);
    const availableThrust = (dragAt(targetSpeed) * 1.3 + BODY_LENGTH * 0.27) * p.amplitude;
    if (targetSpeed < 0.015 || forcedGlide) {
      this.beating = false;
    } else if (this.stateTime > 0.3) {
      if (this.beating && this.speed > targetSpeed * 1.12) {
        this.beating = false;
        this.stateTime = 0;
      } else if (!this.beating && this.speed < targetSpeed * 0.85) {
        this.beating = true;
        this.stateTime = 0;
      }
    }
    const holding = clamp((dragAt(this.speed) + (targetSpeed - this.speed) * 1.5) / availableThrust, 0, 1);
    let command = mix(holding, this.beating ? 1 : 0, p.rhythm);
    if (bursting) command = 1;
    if (forcedGlide || targetSpeed < 0.015) command = 0;
    this.effort = approach(this.effort, command, command > this.effort ? 5 : 3, dt);
    const thrust = this.effort * availableThrust;
    const turningLoss = Math.abs(this.omega) * this.speed * 0.12;
    this.speed = clamp(this.speed + (thrust - dragAt(this.speed) - turningLoss) * dt, 0, BODY_LENGTH * 2.3);
    const travelled = this.speed * dt;
    this.x += Math.cos(this.yaw) * travelled;
    this.z += Math.sin(this.yaw) * travelled;
    this.y = 0.027 * Math.sin(this.time * 0.47) + 0.012 * Math.sin(this.time * 0.83);
    this.distance += travelled;
    this.frequency = (0.64 + 1.12 * this.speed / BODY_LENGTH) * p.tempo;
    this.phase += Math.PI * 2 * this.frequency * dt * mix(0.55, 1, this.effort);
    const last = this.history[this.history.length - 1];
    if (this.distance - last.d > 0.025) {
      this.history.push({ x: this.x, y: this.y, z: this.z, yaw: this.yaw, d: this.distance });
      while (this.history.length > 2 && this.history[1].d < this.distance - BODY_LENGTH * 2.5) this.history.shift();
    }
  }

  past(distance) {
    const d = this.distance - distance;
    const h = this.history;
    let low = 0;
    let high = h.length - 1;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (h[mid].d <= d) low = mid;
      else high = mid - 1;
    }
    const a = h[low];
    const b = h[low + 1] || { x: this.x, y: this.y, z: this.z, yaw: this.yaw, d: this.distance };
    const u = clamp((d - a.d) / Math.max(0.000001, b.d - a.d), 0, 1);
    return { yaw: a.yaw + angleDifference(b.yaw, a.yaw) * u, y: mix(a.y, b.y, u) };
  }

  updateSpine() {
    const n = JOINT_COUNT;
    const length = BODY_LENGTH / (n - 1);
    Object.assign(this.spine[0], { x: this.x, y: this.y, z: this.z });
    for (let i = 1; i < n; i++) {
      const s = (i - 0.5) / (n - 1);
      const old = this.past(s * BODY_LENGTH);
      const envelope = Math.pow(smoothstep(0.13, 1, s), 1.0 + this.params.stiffness * 1.65);
      const amplitude = (0.025 + Math.pow(this.effort, 0.8) * 0.64) * this.params.amplitude;
      const wave = Math.sin(this.phase - s * 5.8) * envelope * amplitude;
      const heading = old.yaw + wave;
      const prev = this.spine[i - 1];
      const rise = clamp((old.y - prev.y) * 0.18, -0.03, 0.03);
      const horizontal = Math.sqrt(1 - rise * rise);
      Object.assign(this.spine[i], {
        x: prev.x - Math.cos(heading) * length * horizontal,
        y: prev.y + rise * length,
        z: prev.z - Math.sin(heading) * length * horizontal,
      });
    }
    return this.spine;
  }

  get state() {
    if (this.time < this.glideUntil) return 'Gliding';
    if (this.time < this.burstUntil) return 'Tail burst';
    if (this.effort < 0.22) return 'Gliding';
    if (Math.abs(this.omega) > 0.22) return 'Turning';
    return this.beating ? 'Tail beating' : 'Settling';
  }
}
